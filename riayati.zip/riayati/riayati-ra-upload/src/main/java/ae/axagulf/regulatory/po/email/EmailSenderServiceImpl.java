package ae.axagulf.regulatory.po.email;

import ae.axagulf.regulatory.po.model.RaUploadStatus;
import ae.axagulf.regulatory.po.utils.AppConstants;
import com.amazonaws.handlers.AsyncHandler;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceAsync;
import com.amazonaws.services.simpleemail.model.RawMessage;
import com.amazonaws.services.simpleemail.model.SendRawEmailRequest;
import com.amazonaws.services.simpleemail.model.SendRawEmailResult;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

import javax.activation.DataHandler;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.*;

@Service
@Log4j2
public class EmailSenderServiceImpl implements EmailSenderService{


    @Autowired
    private SpringTemplateEngine templateEngine;

    @Autowired
    private Environment env;

    @Autowired
    private AmazonSimpleEmailServiceAsync awsSesClient;

    @Value("${riayati.ra.upload.notification.to.list}")
    private String[] raUploadNotificationToList;

    @Value("${riayati.ra.upload.notification.cc.list}")
    private String[] raUploadNotificationCcList;

    @Value("${riayati.ra.upload.notification.bcc.list}")
    private String[] raUploadNotificationBccList;

    @Value("${email.notification.enabled}")
    public boolean isNotificatioEnabled;

    @Async
    @Override
    public void sendNotification(List<RaUploadStatus> raUploadStatuses){

        if(!isNotificatioEnabled){
            log.info("EMAIL NOTIFICATION IS DISABLED !!!");
            return;
        }

        Map<String, Object> templateData = new HashMap<>();
        templateData.put("ratxns",raUploadStatuses);
        SendEmailRequest sendEmailRequest =
                SendEmailRequest.builder()
                        .to(raUploadNotificationToList)
                        .cc(raUploadNotificationCcList)
                        .bcc(raUploadNotificationBccList)
                        .subject(AppConstants._RA_DHPO_UPLOAD_NOTIFICATION_SUBJECT)
                        .templateData(templateData)
                        .templateId(AppConstants._RA_DHPO_NOTIFICATION_TEMPLATE_ID)
                        .build();
        sendEmail(sendEmailRequest);
    }

    @Async
    @Override
    public void sendEmail(SendEmailRequest sendEmailRequest){
        if(!isNotificatioEnabled){
            System.out.println("EMAIL NOTIFICATION IS DISABLED !!!");
            return;
        }
        try {
            Session session = Session.getDefaultInstance(new Properties());
            // Create a new MimeMessage object.
            MimeMessage message = new MimeMessage(session);
            // Add subject, from and to lines.
            message.setSubject(sendEmailRequest.getSubject(), "UTF-8");
            message.setFrom(new InternetAddress(
                    env.getProperty(
                            String.format("email.template.%s",sendEmailRequest.getTemplateId()))));
            String toAddress =
                    String.join(",", Arrays.asList(sendEmailRequest.getTo()) );
            message.setRecipients(Message.RecipientType.TO,
                    InternetAddress.parse(toAddress));

            if (sendEmailRequest.getCc() != null
                    && sendEmailRequest.getCc().length > 0 ) {
                String ccAddress =
                        String.join(",", Arrays.asList(sendEmailRequest.getCc()) );
                message.setRecipients(Message.RecipientType.CC,
                        InternetAddress.parse(ccAddress));
            }

            if (sendEmailRequest.getBcc() != null
                    && sendEmailRequest.getBcc().length > 0) {
                String bccAddress =
                        String.join(",", Arrays.asList(sendEmailRequest.getBcc()) );
                message.setRecipients(Message.RecipientType.BCC,
                        InternetAddress.parse(bccAddress));
            }

            // Create a multipart/alternative child container.
            MimeMultipart msg_body = new MimeMultipart("alternative");

            // Create a wrapper for the HTML and text parts.
            MimeBodyPart wrap = new MimeBodyPart();

            // Define the HTML part.
            String emailBodyHtml =
                    getHtmlBodyById(sendEmailRequest.getTemplateId(), sendEmailRequest.getTemplateData());
            MimeBodyPart htmlPart = new MimeBodyPart();
            htmlPart.setContent(emailBodyHtml, "text/html; charset=UTF-8");
            // Add the text and HTML parts to the child container.
            msg_body.addBodyPart(htmlPart);

            // Add the child container to the wrapper object.
            wrap.setContent(msg_body);

            // Create a multipart/mixed parent container.
            MimeMultipart msg = new MimeMultipart("mixed");

            // Add the parent container to the message.
            message.setContent(msg);

            // Add the multipart/alternative part to the message.
            msg.addBodyPart(wrap);
            if(sendEmailRequest.getAttachments() !=  null){
                for (Attachment attachment : sendEmailRequest.getAttachments()
                ) {
                    MimeBodyPart att = new MimeBodyPart();
                    ByteArrayDataSource bds =
                            new ByteArrayDataSource(
                                    new ByteArrayInputStream(attachment.getContent()),
                                    env.getProperty(
                                            FilenameUtils.getExtension(
                                                    attachment.getFileName())));
                    att.setDataHandler(new DataHandler(bds));
                    att.setFileName(attachment.getFileName());
                    // Add the attachment to the message.
                    msg.addBodyPart(att);
                }
            }

            // Try to send the email.
            log.info("Attempting to send an email through Amazon SES ");

            // Send the email.
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            message.writeTo(outputStream);
            RawMessage rawMessage =
                    new RawMessage(ByteBuffer.wrap(outputStream.toByteArray()));

            SendRawEmailRequest rawEmailRequest =
                    new SendRawEmailRequest(rawMessage);

            //Option2: Async email sending with call back handlers - RECOMMENDED
            awsSesClient.sendRawEmailAsync(rawEmailRequest,
                    new AsyncHandler<SendRawEmailRequest, SendRawEmailResult>() {
                        public void onSuccess(SendRawEmailRequest request, SendRawEmailResult result) {
                            log.info("Success callback:");
                            log.info("MessageId: {}", result.getMessageId());
                            log.info("ResponseMetadata: {}",result.getSdkResponseMetadata());
                        }
                        public void onError(Exception e) {
                            log.error("Error describing table: {}",  e.getMessage());
                        }
                    });
            log.info("EMAIL IS SENT !!!");
        } catch (Exception ex) {
            log.error("Email request is Failed");
            log.error("Error message: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private String getHtmlBodyById(String templateId, Map<String, Object> placeHolder){
        Context context = new Context();
        context.setVariables(placeHolder);
        return templateEngine.process(templateId, context);
    }

}
