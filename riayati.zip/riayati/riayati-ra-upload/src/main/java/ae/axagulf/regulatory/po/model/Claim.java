package ae.axagulf.regulatory.po.model;

import lombok.Data;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@Data
//@Builder
@XmlRootElement(name="Claim")
@XmlAccessorType(XmlAccessType.FIELD)
public class Claim {

    @XmlElement(name = "ID")
    private String id;
    @XmlElement(name = "IDPayer")
    private String idPayer;
    @XmlElement(name = "ProviderID")
    private String providerID;

    @XmlElement(name = "DenialCode")
    private String denialCode;


    @XmlElement(name = "PaymentReference")
    private String paymentReference;
    @XmlElement(name = "DateSettlement")
    private String dateSettlement;
    @XmlElement(name = "Comments")
    private String comments;
    @XmlElement(name = "Encounter")
    private Encounter encounter;
    @XmlElement(name = "Activity")
    private List<Activity> Activity;
}
