package ae.axagulf.regulatory.po.model;


import lombok.Data;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Data
//@Builder
@XmlRootElement(name="Encounter")
@XmlAccessorType(XmlAccessType.FIELD)
public class Encounter {
    @XmlElement(name = "FacilityID")
    private String facilityID;
}
