package ae.axagulf.regulatory.po.services;



import ae.axagulf.regulatory.po.utils.AppConstants;

import ae.axagulf.rest.adapter.CallRequest;
import ae.axagulf.rest.adapter.CallResponse;
import ae.axagulf.rest.adapter.RestAdapter;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@Log4j2
public class RaUploadService {

    @Value("${riayati.ra.upload.wsUrl}")
    String riayatiWsUrl;

    @Value("${axa.http.proxy.host}")
    String proxyHost;

    @Value("${axa.http.proxy.port}")
    int proxyPort;

    @Value("${riayati.api.call.via.proxy}")
    boolean isRiayatiApiCallViaProxy;

    @Value("${riayati.ra.api.request.timeout}")
    int riayatiApiRequestTimeout;

    @Value("${riayati.ws.un}")
    String riayatiWsUname;

    @Value("${riayati.ws.pwd}")
    String riayatiWsPwd;

    public CallResponse uploadRaFile(String fileName, String reqData) {
        CallRequest callRequest = buildCallRequest(reqData);
        RestAdapter adapter = new RestAdapter();
        return adapter.call(callRequest);
    }

    public CallRequest buildCallRequest(String restBody) {
        CallRequest callRequest = new CallRequest();

        callRequest.setProxyHost(proxyHost);
        callRequest.setProxyPort(proxyPort);
        callRequest.setViaProxy(isRiayatiApiCallViaProxy);
        callRequest.setServiceURL(riayatiWsUrl);
        callRequest.setRequestTimeout(0);
        Map<String, String> reqHeaders = new HashMap<>();
        reqHeaders.put("Content-Type", "application/json");
        reqHeaders.put("username", "INS010");
        reqHeaders.put("password", "vwok@30");
        callRequest.setHttpHeaders(reqHeaders);
        callRequest.setRequestData(restBody);
        return callRequest;
    }
}
