package ae.axagulf.regulatory.po.exceptions;

public class NonExistenceExcelDataSheetException extends RuntimeException {

    public NonExistenceExcelDataSheetException(String message){
        super(message);
    }
}
