package ae.axagulf.regulatory.po.jobs;

import ae.axagulf.regulatory.po.email.EmailSenderService;
import ae.axagulf.regulatory.po.exceptions.ExcelsheetExceedException;
import ae.axagulf.regulatory.po.exceptions.NonExistenceExcelDataSheetException;
import ae.axagulf.regulatory.po.handlers.RiayatiRaGenerationHandler;
import ae.axagulf.regulatory.po.model.RaUploadResponse;
import ae.axagulf.regulatory.po.model.RaUploadStatus;
import ae.axagulf.regulatory.po.model.Remittance;
import ae.axagulf.regulatory.po.services.RaUploadService;
import ae.axagulf.regulatory.po.utils.AppConstants;
import ae.axagulf.regulatory.po.utils.DateUtils;
import ae.axagulf.rest.adapter.CallResponse;
import com.amazonaws.util.StringUtils;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.io.FilenameUtils;
import org.apache.poi.util.RecordFormatException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.LinkedList;

@Component
@Log4j2
public class RiayatiRaUploadJob {

    @Autowired
    RiayatiRaGenerationHandler riayatiRaGenerationHandler;

    @Autowired
    RaUploadService raUploadService;

    @Value("${riayati.ra.upload.source.network.root.dir}")
    String raNetworkRootDir;

    @Value("${riayati.ra.upload.input.dir}")
    String raInputDir;

    @Value("${riayati.ra.upload.file.read.limit}")
    int raUploadFileReadLimit;

    @Value("${riayati.ra.upload.job.state}")
    int jobState;

    @Autowired
    EmailSenderService emailSenderService;

    @Scheduled(cron = "${riayati.ra.upload.job.scheduled}")
    public void run() {
        try{
            if(jobState == 0){
                log.info("JOB STATE >> {}", jobState);
                return;
            }
            riayatiRaGenerationHandler.initializeDefaultFolders();
            var raUploadStatuses = new LinkedList<RaUploadStatus>();
            var now = DateUtils.now(LocalDateTime.now(), AppConstants._RA_UPLOAD_DATE_NOTIFICATION_FORMAT);
            log.info(" ----------- NEW JOB STARTED ------------");
            Path inputDir = Paths.get(raNetworkRootDir).resolve(raInputDir);
            log.info("Riayati SOURCE DIR PATH: >> {}",inputDir);
            log.info("FILE READ LIMIT >> {}", raUploadFileReadLimit);

            Files.find(inputDir, 10, (path, attribs)->{
                return Files.isRegularFile(path);
            })
            .limit(raUploadFileReadLimit)
            .forEach((path)->{
                String srcFileName = path.getFileName().toString();
                if(!riayatiRaGenerationHandler.isValidFileExtension(path)){
                    log.info("INVALID FILE EXTENSION FOUND : "
                            +FilenameUtils.getExtension(srcFileName));
                    riayatiRaGenerationHandler.handleInvalidFileErrors(path,
                            AppConstants._RA_ERROR_NAME_IDENTIFIER_INVALID_FILE_EXT,
                            AppConstants._RA_INAVALID_FILE_EXTENSION_ERROR);
                    raUploadStatuses.add(RaUploadStatus.builder()
                                        .fileName(srcFileName)
                                        .uploadDate(now)
                                        .status(AppConstants._RA_UPLOAD_FAILURE)
                                        .statusDesc(String.format("%s:%s",
                                                AppConstants._RA_ERROR_NAME_IDENTIFIER_INVALID_FILE_EXT,
                                                AppConstants._RA_INAVALID_FILE_EXTENSION_ERROR)).build());
                    return;
                }
                log.info("Riayati FILE NAME UNDER PROCESSING >> {}",path.getFileName());
                // Step1:
                LinkedList<LinkedList<String>> excelRows = null;
                try {
                    excelRows = riayatiRaGenerationHandler.readExcelRows(path);
                }catch (NonExistenceExcelDataSheetException e){
                    log.info("RA DATA SHEET NOT FOUND.");
                    riayatiRaGenerationHandler.handleInvalidFileErrors(path,
                            AppConstants._RA_ERROR_NAME_EXCEL_DATA_SHEET_NOT_FOUND,
                            AppConstants._RA_EXCEL_DATA_SHEET_NOT_FOUND_MSG);
                    raUploadStatuses.add(RaUploadStatus.builder()
                            .fileName(srcFileName)
                            .uploadDate(now)
                            .status(AppConstants._RA_UPLOAD_FAILURE)
                            .statusDesc(String.format("%s:%s",
                                    AppConstants._RA_ERROR_NAME_EXCEL_DATA_SHEET_NOT_FOUND,
                                    AppConstants._RA_EXCEL_DATA_SHEET_NOT_FOUND_MSG)).build());
                    return;

                }catch (ExcelsheetExceedException e){
                    log.info("MORE THAN ONE EXCEL SHEET FOUND.");
                    riayatiRaGenerationHandler.handleInvalidFileErrors(path,
                                                                   AppConstants._RA_ERROR_NAME_IDENTIFIER_MULTIPLE_EXCEL_SHEETS,
                                                                   AppConstants._RA_MULTIPLE_EXCEL_SHEETS_MSG);
                    raUploadStatuses.add(RaUploadStatus.builder()
                            .fileName(srcFileName)
                            .uploadDate(now)
                            .status(AppConstants._RA_UPLOAD_FAILURE)
                            .statusDesc(String.format("%s:%s",
                                    AppConstants._RA_ERROR_NAME_IDENTIFIER_MULTIPLE_EXCEL_SHEETS,
                                    AppConstants._RA_MULTIPLE_EXCEL_SHEETS_MSG)).build());
                    return;
                }catch(RecordFormatException rfe){
                    riayatiRaGenerationHandler.handleInvalidFileErrors(path,
                            AppConstants._RA_ERROR_NAME_EXCLE_READ_UNEXPECTED_ERROR,
                            rfe.getMessage()+":"+ "Save excel workbook with 97-2003 and retry.");
                    raUploadStatuses.add(RaUploadStatus.builder()
                            .fileName(srcFileName)
                            .uploadDate(now)
                            .status(AppConstants._RA_UPLOAD_FAILURE)
                            .statusDesc(String.format("%s:%s",
                                    AppConstants._RA_ERROR_NAME_EXCLE_READ_UNEXPECTED_ERROR,
                                    rfe.getMessage())).build());
                    return;
                }
                catch (Exception e){
                    log.error("UNEXPECTED ERROR WHILE READING EXCEL DATA.");
                    e.printStackTrace();
                    riayatiRaGenerationHandler.handleInvalidFileErrors(path,
                            AppConstants._RA_ERROR_NAME_EXCLE_READ_UNEXPECTED_ERROR,
                            e.getMessage());
                    raUploadStatuses.add(RaUploadStatus.builder()
                            .fileName(srcFileName)
                            .uploadDate(now)
                            .status(AppConstants._RA_UPLOAD_FAILURE)
                            .statusDesc(String.format("%s:%s",
                                    AppConstants._RA_ERROR_NAME_EXCLE_READ_UNEXPECTED_ERROR,
                                    e.getMessage())).build());

                    return;
                }
                if(excelRows == null){
                    riayatiRaGenerationHandler.handleWrongExcelSheetName(path);
                    return;
                }
                var excelDataProcessingOutput = riayatiRaGenerationHandler.validateAndConvertExcelRowsToRaObjs(excelRows);

                if(excelDataProcessingOutput.isDataValidatioErrorsExist()){
                    log.error("EXCEL DATA VALIDATION ERRORS FOUND !!!");
                    riayatiRaGenerationHandler.handleInvalidDataErrors(path, excelDataProcessingOutput.getValidationErrors());
                    raUploadStatuses.add(RaUploadStatus.builder()
                            .fileName(srcFileName)
                            .uploadDate(now)
                            .status(AppConstants._RA_UPLOAD_FAILURE)
                            .statusDesc(String.format("%s:%s",
                                    "INVALID-DATA-ERRORS",
                                    "Invalid data need to be corrected.")).build());
                    return;
                }

                var remittanceAdvice = riayatiRaGenerationHandler.convertRaObjsToRemittanceAdvice(excelDataProcessingOutput.getRaDataList());
                Remittance Remittance =new Remittance();
                Remittance.setRemittance(remittanceAdvice);
                String raJsonStr = riayatiRaGenerationHandler.convertObjectToJson(Remittance);
                log.info(raJsonStr);

//                StringEntity entity = new StringEntity(raJsonStr,
//                        ContentType.APPLICATION_FORM_URLENCODED);
//
//
//                HttpClient httpClient = HttpClientBuilder.create().build();
//
//                HttpPost request = new HttpPost("https://o-tmbapi.riayati.ae:8083/");
//                //HttpPost request = new HttpPost("https://o-tmbapi.riayati.ae:8083/api/Claim/PostRemittance");
//                request.addHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
//                request.addHeader("username","INS010");
//                request.addHeader("password","vwok@30");
//                request.addHeader("SOAPAction","https://o-tmbapi.riayati.ae:8083/api/Claim/PostRemittance");
//                request.setEntity(entity);
//try{
//    HttpResponse response = httpClient.execute(request);
//    System.out.println("Response returned from call::"+response.getStatusLine().getStatusCode());
//}catch (ClientProtocolException e) {
//    e.printStackTrace();
//} catch (IOException e) {
//    e.printStackTrace();
//}


                if(!StringUtils.isNullOrEmpty(raJsonStr)){
                    //-- Upload to Riayati
                    String origFileNameWithoutExtension =
                            FilenameUtils.removeExtension(path.getFileName().toString());
                    String dateTimeStr =
                            DateUtils.now(LocalDateTime.now(), AppConstants._RA_UPLOAD_FILE_DATE_APPENDED_FORMAT);
                    String raUploadFileName = String.format("%s-%s.json", origFileNameWithoutExtension, dateTimeStr);
                    CallResponse callResponse =
                            raUploadService.uploadRaFile(raUploadFileName, raJsonStr);
                    System.out.println("Status Code >>>>>>>>> "+callResponse.getStatusCode());
                    System.out.println("Response Body >>>>>>>>> "+callResponse.getResponseData());
                    if(true) return;
                    RaUploadResponse raUploadResponse = riayatiRaGenerationHandler.extractRaUploadResponse(callResponse);//, raUploadFileName, raXmlStr, path);
                    switch(raUploadResponse.getUploadStatus()){
                        case "SUCCESS":
                            log.info("RA UPLOAD ::: SUCCESS !!!");
                            riayatiRaGenerationHandler.handleSuccessResponse(path,
                                                                          raUploadFileName,
                                                                          remittanceAdvice.getHeader().getReceiverID(),
                                                                          raJsonStr);
                            raUploadStatuses.add(RaUploadStatus.builder()
                                    .fileName(srcFileName)
                                    .uploadDate(now)
                                    .status(AppConstants._RA_UPLOAD_SUCCESS)
                                    .statusDesc("File successfully uploaded to DHPO").build());
                            break;
                        case "FAILED":
                            log.info("RA UPLOAD ::: FAILED !!!");
                            riayatiRaGenerationHandler.handleRegulatoryFailureResponse(path,
                                                                                    raUploadFileName,
                                                                                    raJsonStr,
                                                                                    remittanceAdvice.getHeader().getReceiverID(),
                                                                                    raUploadResponse.getUploadStatusDesc(),
                                                                                    raUploadResponse.getErrorReport());
                            raUploadStatuses.add(RaUploadStatus.builder()
                                    .fileName(srcFileName)
                                    .uploadDate(now)
                                    .status(AppConstants._RA_UPLOAD_FAILURE)
                                    .statusDesc(raUploadResponse.getUploadStatusDesc()).build());
                            break;
                        case "API_INVOCATION_ERROR":
                            log.info("RA UPLOAD ::: API_INVOCATION_ERROR !!!");
                            riayatiRaGenerationHandler.handleApiInvocationResponse(path,
                                                                                raUploadFileName,
                                                                                raJsonStr,
                                                                                remittanceAdvice.getHeader().getReceiverID(),
                                                                                callResponse.getStatusDesc());
                            raUploadStatuses.add(RaUploadStatus.builder()
                                    .fileName(srcFileName)
                                    .uploadDate(now)
                                    .status(AppConstants._RA_UPLOAD_FAILURE)
                                    .statusDesc("API_INVOCATION_ERROR: "+callResponse.getStatusDesc()).build());
                            break;
                    }
                }
            });

            if(raUploadStatuses.size() > 0){
                emailSenderService.sendNotification(raUploadStatuses);
            }

            log.info(" ----------- JOB COMPLETED ------------");
        }catch (Exception e){
            e.printStackTrace();
        }
    }


}
