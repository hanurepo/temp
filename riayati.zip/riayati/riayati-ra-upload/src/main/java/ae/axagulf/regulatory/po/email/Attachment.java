package ae.axagulf.regulatory.po.email;

import lombok.Data;

@Data
public class Attachment {
    private byte[] content;
    private String fileName;
}
