package ae.axagulf.regulatory.po.email;


import ae.axagulf.regulatory.po.model.RaUploadStatus;

import java.util.List;

public interface EmailSenderService {

    public void sendNotification(List<RaUploadStatus> raUploadStatuses);
    public void sendEmail(SendEmailRequest sendEmailRequest);//, String ackId);
}
