package ae.axagulf.rest.adapter;

import java.util.Map;


public class CallRequest {
    public CallRequest() {
        super();
    }
    
    private String serviceURL;
    private String requestData;
    private Map<String,String> httpHeaders;    
    private boolean viaProxy = false;
    private String proxyHost;
    private int proxyPort;
    private int requestTimeout;


    public void setServiceURL(String serviceURL) {
        this.serviceURL = serviceURL;
    }

    public String getServiceURL() {
        return serviceURL;
    }

    public void setViaProxy(boolean viaProxy) {
        this.viaProxy = viaProxy;
    }

    public boolean isViaProxy() {
        return viaProxy;
    }

    public void setProxyHost(String proxyHost) {
        this.proxyHost = proxyHost;
    }

    public String getProxyHost() {
        return proxyHost;
    }

    public void setProxyPort(int proxyPort) {
        this.proxyPort = proxyPort;
    }

    public int getProxyPort() {
        return proxyPort;
    }

    public void setHttpHeaders(Map<String, String> httpHeaders) {
        this.httpHeaders = httpHeaders;
    }

    public Map<String, String> getHttpHeaders() {
        return httpHeaders;
    }

        public int getRequestTimeout() {
        return requestTimeout;
    }

    public void setRequestTimeout(int requestTimeout) {
        this.requestTimeout = requestTimeout;
    }


    public String getRequestData() {
        return requestData;
    }

    public void setRequestData(String requestData) {
        this.requestData = requestData;
    }

}
