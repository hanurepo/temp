package ae.axagulf.rest.adapter;

import org.apache.http.HttpHost;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.*;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class HttpClientWrapper {
    public HttpClientWrapper() {
        super();
    }

    private static final int _MILLI_SECONDS = 1000;

    /**
     * This is an updated and recommended client version with Request Timeout feature.
     * @param callRequest
     * @return CloseableHttpClient
     */
    public static CloseableHttpClient wrapClient(CallRequest callRequest) {
        try {
            int requestTimeout = callRequest.getRequestTimeout();
            HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
            if (requestTimeout > 0) {
                System.out.println(String.format("API Request Timeout is configured for [%s] seconds.", requestTimeout));
                RequestConfig config = RequestConfig.custom()
                        .setConnectTimeout(requestTimeout * _MILLI_SECONDS)
                        .setConnectionRequestTimeout(requestTimeout * _MILLI_SECONDS)
                        .setSocketTimeout(requestTimeout * _MILLI_SECONDS)
                        .build();
                httpClientBuilder.setDefaultRequestConfig(config);
            }

            if(callRequest.isViaProxy()){
                System.out.println("API Call is going via proxy server...");
                String proxyHostIP = callRequest.getProxyHost();
                int proxyPort = callRequest.getProxyPort();
                HttpHost proxy = new HttpHost(proxyHostIP, proxyPort);
                httpClientBuilder.setProxy(proxy);
            }

            SSLContext ctx = SSLContext.getInstance("TLS");
            X509TrustManager tm = new X509TrustManager() {

                @Override
                public void checkClientTrusted(
                        java.security.cert.X509Certificate[] chain,
                        String authType)
                        throws java.security.cert.CertificateException {
                    // TODO Auto-generated method stub

                }

                @Override
                public void checkServerTrusted(
                        java.security.cert.X509Certificate[] chain,
                        String authType)
                        throws java.security.cert.CertificateException {
                    // TODO Auto-generated method stub

                }

                @Override
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    // TODO Auto-generated method stub
                    return null;
                }
            };
            ctx.init(null, new TrustManager[] { tm }, null);
            SSLSocketFactory ssf = new SSLSocketFactory(ctx);
            ssf.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
            CloseableHttpClient client = httpClientBuilder
                    .setSSLContext(ctx)
                    .setSSLSocketFactory(ssf)
                    .setSSLHostnameVerifier((s1,s2)-> true)
                    .build();
            return client;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    CloseableHttpClient getHttpsClient()
    {
        try
        {
            RequestConfig config = RequestConfig.custom().setSocketTimeout( 5000 ).setConnectTimeout( 5000 ).build();

            SSLContextBuilder sslContextBuilder = new SSLContextBuilder();
            sslContextBuilder.loadTrustMaterial( null, (TrustStrategy) (x509Certificates, s ) -> true );
            SSLConnectionSocketFactory sslSocketFactory =
                    new SSLConnectionSocketFactory( sslContextBuilder.build(), NoopHostnameVerifier.INSTANCE );

            return HttpClients.custom().setDefaultRequestConfig( config ).setSSLSocketFactory( sslSocketFactory )
                    .build();
        }
        catch ( Exception e )
        {
            e.printStackTrace();
        }

        return HttpClients.createDefault();
    }


    /**
     * Traditional approach, Not recommended to use.
     * @param base
     * @return
     */
    @Deprecated
    public static HttpClient wrapClient(HttpClient base) {
        try {
            SSLContext ctx = SSLContext.getInstance("TLS");
            X509TrustManager tm = new X509TrustManager() {

                //@Override
                public void checkClientTrusted(
                        java.security.cert.X509Certificate[] chain,
                        String authType)
                        throws java.security.cert.CertificateException {
                    // TODO Auto-generated method stub

                }

                //@Override
                public void checkServerTrusted(
                        java.security.cert.X509Certificate[] chain,
                        String authType)
                        throws java.security.cert.CertificateException {
                    // TODO Auto-generated method stub

                }

                //@Override
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    // TODO Auto-generated method stub
                    return null;
                }
            };
            ctx.init(null, new TrustManager[]{tm}, null);
            SSLSocketFactory ssf = new SSLSocketFactory(ctx);
            ssf.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
            ClientConnectionManager ccm = base.getConnectionManager();
            SchemeRegistry sr = ccm.getSchemeRegistry();
            sr.register(new Scheme("https", ssf, 443));
            return new DefaultHttpClient(ccm, base.getParams());
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }


}
