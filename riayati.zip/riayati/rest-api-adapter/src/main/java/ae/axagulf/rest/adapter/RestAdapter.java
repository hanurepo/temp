package ae.axagulf.rest.adapter;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;

import java.net.SocketTimeoutException;
import java.util.HashMap;
import java.util.Map;

public class RestAdapter {
    public ae.axagulf.rest.adapter.CallResponse call(CallRequest callRequest){
        ae.axagulf.rest.adapter.CallResponse _return = new ae.axagulf.rest.adapter.CallResponse();
        _return.setStatus("SUCCESS");
        HttpResponse httpResponse = null;
        HttpPost httpPost = null;
        try{
            HttpClient httpClient = HttpClientWrapper.wrapClient(callRequest);
            httpPost = initiateHttpPost(callRequest);
            httpResponse = httpClient.execute(httpPost);
            if(httpResponse == null){
                _return.setStatus("ERROR");
                _return.setStatusDesc(String.format("No response returned from target service URL [%s]",callRequest.getServiceURL()));
                return _return;
            }
            int statusCode = httpResponse.getStatusLine().getStatusCode();
            _return.setStatusCode(statusCode);
            String rawContent = EntityUtils.toString(httpResponse.getEntity(),"UTF-8");
            if(isNullOrEmpty(rawContent)){
                _return.setStatus("ERROR");
                _return.setStatusDesc(String.format("No response content returned from target service URL [%s]",callRequest.getServiceURL()));
                return _return;
            }
            _return.setResponseData(new String(rawContent));

        }catch (SocketTimeoutException ste){
            System.out.println("java.net.SocketTimeoutException: "+ste.getLocalizedMessage());
            _return.setStatus("ERROR");
            _return.setStatusDesc(String.format("API call request timed out in [%s] second(s)", callRequest.getRequestTimeout()));
            _return.setStatusCode(408);
        }catch(Exception e){
            System.out.println(e.getLocalizedMessage());
            e.printStackTrace();
            _return.setStatus("ERROR");
            _return.setStatusDesc(e.getMessage());
            _return.setStatusCode(500);
        }finally{
            if(httpPost != null){
                try{
                    httpPost.releaseConnection();
                }catch(Exception e){
                    ;
                }
            }
        }
        return _return;
    }

    private HttpPost initiateHttpPost(CallRequest callRequest){
        HttpPost httpPost = new HttpPost(callRequest.getServiceURL());
        try{
            //Add headers
            Map<String,String> headersMap = callRequest.getHttpHeaders();
            if(headersMap == null){
                headersMap = new HashMap<String,String>();
            }
            headersMap.put("Content-Type", "application/json");
            headersMap.put("Accept", "application/json");
            //headersMap.put("SOAPAction",String.format("\"%s\"",callRequest.getSoapAction()));
            for(Map.Entry<String,String> entry : headersMap.entrySet()){
                Header reqHeader = new BasicHeader(entry.getKey(),entry.getValue()) ;
                httpPost.addHeader(reqHeader);
            }
            StringEntity body = new StringEntity(callRequest.getRequestData());
            httpPost.setEntity(body);
        }catch(Exception e){
            e.printStackTrace();
        }
        return httpPost;
    }


    public static boolean isNullOrEmpty(String str) {
        return str == null || str.length() == 0;
    }

}
