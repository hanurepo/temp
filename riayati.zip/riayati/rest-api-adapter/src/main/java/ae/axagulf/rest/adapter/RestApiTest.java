package ae.axagulf.rest.adapter;

import java.util.HashMap;
import java.util.Map;

public class RestApiTest {

 String riayatiWsUrl = "https://o-tmbapi.riayati.ae:8083/api/Claim/PostRemittance";


    String jsonStr = "{\n" +
            "\n" +
            "   \"Remittance\":{\n" +
            "\n" +
            "      \"Header\":{\n" +
            "\n" +
            "         \"SenderID\":\"INS010\",\n" +
            "\n" +
            "         \"ReceiverID\":\"MOH-F-5000592\",\n" +
            "\n" +
            "         \"TransactionDate\":\"17/11/2021 11:46\",\n" +
            "\n" +
            "         \"RecordCount\":\"1\",\n" +
            "\n" +
            "         \"DispositionFlag\":\"PRODUCTION\",\n" +
            "\n" +
            "         \"PayerID\":\"1234\"\n" +
            "\n" +
            "      },\n" +
            "\n" +
            "      \"Claim\":[\n" +
            "\n" +
            "         {\n" +
            "\n" +
            "            \"Id\":\"MOH-F-5000592_INS010_20210603_2859964\",\n" +
            "\n" +
            "            \"IdPayer\":\"13/XC/7042629\",\n" +
            "\n" +
            "            \"ProviderID\":\"MOH-F-5000592\",\n" +
            "\n" +
            "            \"DenialCode\":\"23432\",\n" +
            "\n" +
            "            \"PaymentReference\":\"100001011591\",\n" +
            "\n" +
            "            \"DateSettlement\":\"20/06/2021 12:00\",\n" +
            "\n" +
            "            \"Comments\":\"\",\n" +
            "\n" +
            "            \"Encounter\":{\n" +
            "\n" +
            "               \"FacilityID\":\"MOH-F-5000592\"\n" +
            "\n" +
            "            },\n" +
            "\n" +
            "            \"Activity\":[\n" +
            "\n" +
            "               {\n" +
            "\n" +
            "                  \"Id\":\"8858397\",\n" +
            "\n" +
            "                  \"Start\":\"03/06/2021 00:00\",\n" +
            "\n" +
            "                  \"Type\":5,\n" +
            "\n" +
            "                  \"Code\":\"0077-258502-1171\",\n" +
            "\n" +
            "                  \"Quantity\":\"20.0\",\n" +
            "\n" +
            "                  \"Net\":\"11.86\",\n" +
            "\n" +
            "                  \"List\":\"25.5\",\n" +
            "\n" +
            "                  \"Clinician\":\"MOHD46710\",\n" +
            "\n" +
            "                  \"PriorAuthorizationID\":\"PBM_2859964_15002\",\n" +
            "\n" +
            "                  \"Gross\":\"11.86\",\n" +
            "\n" +
            "                  \"PatientShare\":\"0.0\",\n" +
            "\n" +
            "                  \"ActivityPenalty\":null,\n" +
            "\n" +
            "                  \"PaymentAmount\":\"11.86\",\n" +
            "\n" +
            "                  \"DenialCode\":\"2312\",\n" +
            "\n" +
            "                  \"Comments\":null\n" +
            "\n" +
            "               }\n" +
            "\n" +
            "            ]\n" +
            "\n" +
            "         }\n" +
            "\n" +
            "      ]\n" +
            "\n" +
            "   }\n" +
            "\n" +
            "}";


    public static void main(String[] args) {
        RestApiTest test = new RestApiTest();
        CallResponse resp = test.uploadRaFile(null, test.jsonStr);
        System.out.println("Status code >>>>> "+ resp.getStatusCode());
        System.out.println("Resp xml >>>>> "+ resp.getResponseData());
    }


    public CallResponse uploadRaFile(String fileName, String jsonStr) {
        CallRequest callRequest = buildCallRequest(jsonStr);
        RestAdapter adapterV2 = new RestAdapter();
        return adapterV2.call(callRequest);
    }

    public CallRequest buildCallRequest(String restBody) {
        CallRequest callRequest = new CallRequest();

//        callRequest.setProxyHost(proxyHost);
//        callRequest.setProxyPort(proxyPort);
//        callRequest.setViaProxy(isRiayatiApiCallViaProxy);
        callRequest.setServiceURL(riayatiWsUrl);
        //callRequest.setRequestTimeout(0);
        Map<String, String> reqHeaders = new HashMap<>();
        reqHeaders.put("Content-Type", "application/json");
        reqHeaders.put("username", "INS010");
        reqHeaders.put("password", "vwok@30");
        callRequest.setHttpHeaders(reqHeaders);
        callRequest.setRequestData(restBody);
        return callRequest;
    }
}
