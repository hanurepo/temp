package ae.axagulf.rest.adapter;

public class Constants {
    public static final String removeNSXSLT = "<xsl:stylesheet version=\"1.0\" xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\">\n" +
            "    <xsl:output indent=\"yes\" method=\"xml\" encoding=\"UTF-8\" omit-xml-declaration=\"yes\"/>\n" +
            "    <xsl:template match=\"*\">\n" +
            "        <xsl:element name=\"{local-name()}\">\n" +
            "            <xsl:apply-templates select=\"@* | node()\"/>\n" +
            "        </xsl:element>\n" +
            "    </xsl:template>\n" +
            "    <xsl:template match=\"@*\">\n" +
            "        <xsl:attribute name=\"{local-name()}\">\n" +
            "            <xsl:value-of select=\".\"/>\n" +
            "        </xsl:attribute>\n" +
            "    </xsl:template>\n" +
            "    <xsl:template match=\"comment() | text() | processing-instruction()\">\n" +
            "        <xsl:copy/>\n" +
            "    </xsl:template>\n" +
            "</xsl:stylesheet>";
}
